const express = require('express'); // Express app
const router = express.Router();   // Router logic
const jwt = require('express-jwt');
const auth = jwt({
    secret: process.env.JWT_SECRET,
    userProperty: 'payload'
});

// This is where we import the controllers we will route
const tripsController = require('../controllers/trips');

// define route for our trips endpoint

const authController = require('../controllers/authentication');
const tripsController = require('../controllers/trips');

router
    .route('/trips')
    .get(tripsController.tripList)
    .post(auth,tripController.tripsAddTrip);
router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindCode)
    .put(auth, tripsController.tripsUpdateTrip);

router
    .route('trips')
    .get(tripsController.tripsList); // GET Method routes tripList
    .post(tripsController.tripsAddTrip); // POST Method Adds a Trip

// GET Method routes tripsFindByCode - requires parameter
// PUT Method routes tripsUpdateTrip - requires parameter
router
    .router('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(tripsController.tripsUpdateTrip);

module.exports = router;