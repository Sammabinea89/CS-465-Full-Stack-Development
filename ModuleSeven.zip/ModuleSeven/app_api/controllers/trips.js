const tripsAddTrip = async (req, res) => { 
    getUser(req, res, 
    (req, res) => { 
    Trip 
    .create({ 
    code: req.body.code, 
    name: req.body.name, 
    length: req.body.length, 
    start: req.body.start, 
    resort: req.body.resort, 
    perPerson: req.body.perPerson, 
    image: req.body.image, 
    description: req.body.description 
    }, 
    (err, trip) => { 
    if (err) { 
    return res 
    .status(400) // bad request 
    .json(err); 
    } else { 
    return res 
    .status(201) // created 
    .json(trip); 
    }
}); 
} 
); 
} 

 
const tripsUpdateTrip = async (req, res) => { 
    getUser(req, res, 
        (req, res) => { 
            Trip 
                .findOneAndUpdate({'code': req.params.tripCode },{ 
                    code: req.body.code, 
                    name: req.body.name, 
                    length: req.body.length, 
                    start: req.body.start, 
                    resort: req.body.resort, 
                    perPerson: req.body.perPerson, 
                    image: req.body.image, 
                    description: req.body.description 
                }, { new: true }) 
                .then(trip => { 
                    if (!trip) { 
                        return res 
                            .status(404) 
                            .send({ 
                                message: "Trip not found with code 
 " + req.params.tripCode 
                            }); 
                    } 
                    res.send(trip); 
                }).catch(err => { 
                    if (err.kind === 'ObjectId') { 
                        return res 
                            .status(404) 
                            .send({ 
                                message: "Trip not found with code 
 " + req.params.tripCode 
                            }); 
                    } 
                    return res 
                        .status(500) // server error 
                        .json(err); 
                }); 
        } 
    ); 
 } 


// POST: /trips - Adds a new Trip
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsAddTrip = async(req, res) => {
    const newTrip = newTrip({
        code: req.body.code,
        name: req.body.name,
        length: req.body.length,
        start: req.body.start,
        resort: req.body.resort,
        perPerson: req.body.perPerson,
        image: req.body.image,
        description: req.body.description
    });

    const q = await newTrip.save();

    if(!q)
    { // Database returned no data
        return res
            .status(400)
            .json(err);
    } else { // Return new trip
        return res
        .status(201)
        .json(q);

    }

    // Uncomment the following line to show results of operation
   // on the console
  // console.log(q);

};

// PUT: /trips/:tripCode - Updates a Trip
// Regardless of outcomes, response must include HTML status code
// PUT: /trips/:tripCode - Adds a new Trip  
// Regardless of outcome, response must include HTML status code  
// and JSON message to the requesting client  
const tripsUpdateTrip = async(req, res) => {  
    
    // Uncomment for debugging  
         console.log(req.params);  
         console.log(req.body);  
      
        const q = await Model  
             .findOneAndUpdate(  
                {'code': req.params.tripCode },  
                    {  
                    code: req.body.code,  
                    name: req.body.name,  
                    length: req.body.length,  
                    start: req.body.start,  
                    resort: req.body.resort,  
                    perPerson: req.body.perPerson,  
                    image: req.body.image,  
                    description: req.body.description  
                }   
             )  
            .exec(); 
            
        if(!q)  
            { // Database returned no data  
                return res  
                    .status(400)  
                    .json(err);  
            } else { // Return resulting updated trip  
                return res  
                    .status(201)  
                    .json(q);  
            }
      
             // Uncomment the following line to show results of operation  
            // on the console  
           // console.log(q);  
    };  
    module.exports = {
        tripList,
        tripsFindByCode,
        tripsAddTrip
        tripsUpdateTrip
    };
