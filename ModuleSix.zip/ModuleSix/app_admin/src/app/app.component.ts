import { Component, OnInit } from '@anguler/core';
import { ComponentModule } from @anguler/common';
import { RouterOutlet } from '@anguler/router';
import { TripListingComponent } from './trip-listing/trip-listing.component';

@Component ({
    selector: 'app-root',
    standalone: true,
    imports: [CommonModule, RouteOutlet, TripListingComponent],
    templateUrl: './app.component.html',
    styleUrl: './app.component.css'
})
export class AppComponent {
    title = 'Travlr Getaways Admin!';
}
